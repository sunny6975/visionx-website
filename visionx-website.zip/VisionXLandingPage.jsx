export default function VisionXLandingPage() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <header className="p-6 border-b border-gray-800">
        <h1 className="text-3xl font-bold text-electric-blue">VisionX</h1>
        <p className="text-gray-400">Founded by Sandeep Reddy Sura</p>
      </header>

      <main className="p-10 text-center">
        <h2 className="text-4xl font-bold mb-4">The Future of Intelligent Vision Starts Now</h2>
        <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
          VisionX is transforming how machines and humans see the world. Powered by AI, computer vision, and AR/VR innovation, we bring futuristic experiences into everyday life.
        </p>
        <button className="bg-electric-blue text-black px-6 py-3 rounded-2xl shadow-lg hover:scale-105 transition-transform">
          Join the Movement
        </button>
      </main>

      <section className="p-10 bg-gray-900 grid md:grid-cols-3 gap-6 text-left">
        <div>
          <h3 className="text-xl font-semibold text-white mb-2">🚀 Computer Vision</h3>
          <p className="text-gray-400">Facial recognition, object detection, smart analytics for real-world impact.</p>
        </div>
        <div>
          <h3 className="text-xl font-semibold text-white mb-2">🧠 AI Visual Intelligence</h3>
          <p className="text-gray-400">We merge deep learning with real-time vision to create powerful automation tools.</p>
        </div>
        <div>
          <h3 className="text-xl font-semibold text-white mb-2">🌐 AR/VR Interfaces</h3>
          <p className="text-gray-400">Immersive experiences for design, navigation, and simulation across industries.</p>
        </div>
      </section>

      <footer className="p-6 text-center text-gray-500 border-t border-gray-800">
        <p>&copy; 2025 VisionX | Built by Sandeep Reddy Sura</p>
      </footer>
    </div>
  );
}